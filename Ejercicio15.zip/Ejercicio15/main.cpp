#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayou
#include <QMessageBox>

class Formulario : public QWidget {

public:
    Formulario(QWidget *parent = nullptr) : QWidget(parent) {
        setWindowTitle("Formulario");

        QGridLayout *layout = new QGridLayout(this);

        QLabel *label_legajo = new QLabel("Legajo:");
        edit_legajo = new QLineEdit();
        layout->addWidget(label_legajo, 0, 0);
        layout->addWidget(edit_legajo, 0, 1);

        QLabel *label_nombre = new QLabel("Nombre:");
        edit_nombre = new QLineEdit();
        layout->addWidget(label_nombre, 1, 0);
        layout->addWidget(edit_nombre, 1, 1);

        QLabel *label_apellido = new QLabel("Apellido:");
        edit_apellido = new QLineEdit();
        layout->addWidget(label_apellido, 2, 0);
        layout->addWidget(edit_apellido, 2, 1);

        QPushButton *button_alta = new QPushButton("ALTA");
        connect(button_alta, &QPushButton::clicked, this, &Formulario::alta);
        layout->addWidget(button_alta, 3, 1);

        setLayout(layout);
    }

private slots:
    void alta() {
        // Aquí puedes implementar la lógica para realizar la acción de "ALTA"
        QMessageBox::information(this, "ALTA", "Realizando alta...");
    }

private:
    QLineEdit *edit_legajo;
    QLineEdit *edit_nombre;
    QLineEdit *edit_apellido;
};

class Login : public QWidget {
    Q_OBJECT

public:
    Login(QWidget *parent = nullptr) : QWidget(parent) {
        setWindowTitle("Login");
        setGeometry(200, 200, 300, 150);

        QGridLayout *layout = new QGridLayout(this);

        QLabel *label_nombre = new QLabel("Usuario:");
        edit_nombre = new QLineEdit();
        layout->addWidget(label_nombre, 0, 0);
        layout->addWidget(edit_nombre, 0, 1);

        QLabel *label_clave = new QLabel("Clave:");
        edit_clave = new QLineEdit();
        edit_clave->setEchoMode(QLineEdit::Password);
        layout->addWidget(label_clave, 1, 0);
        layout->addWidget(edit_clave, 1, 1);

        QPushButton *button_login = new QPushButton("Login");
        connect(button_login, &QPushButton::clicked, this, &Login::login);
        layout->addWidget(button_login, 2, 1);

        setLayout(layout);
    }

private slots:
    void login() {
        QString clave = edit_clave->text();
        if (clave == "1111") {
            formulario.show();
            close();
        } else {
            edit_clave->clear();
        }
    }

private:
    QLineEdit *edit_nombre;
    QLineEdit *edit_clave;
    Formulario formulario;
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    Login login;
    login.show();

    return app.exec();
}

#include "main.moc"
