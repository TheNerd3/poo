#include <QApplication>
#include "login.h"
#include "formulario.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    Login login;
    Formulario formulario;

    QObject::connect(&login, &Login::mostrarFormulario, [&]() {
        formulario.show();
        login.close();
    });

    login.show();

    return app.exec();
}
