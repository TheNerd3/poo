#ifndef FORMULARIO_H
#define FORMULARIO_H

#include <QWidget>
#include <QLineEdit>

class Formulario : public QWidget {
    Q_OBJECT
public:
    Formulario(QWidget *parent = nullptr);

signals:
    void cerrar();

private slots:
    void cerrarFormulario();

private:
    QLineEdit *lineEditLegajo;
    QLineEdit *lineEditNombre;
    QLineEdit *lineEditApellido;
};

#endif // FORMULARIO_H
