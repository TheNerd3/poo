#include "formulario.h"
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>

Formulario::Formulario(QWidget *parent) : QWidget(parent) {
    QGridLayout *layout = new QGridLayout(this);

    QLabel *labelLegajo = new QLabel("Legajo:", this);
    layout->addWidget(labelLegajo, 0, 0);
    lineEditLegajo = new QLineEdit(this);
    layout->addWidget(lineEditLegajo, 0, 1);

    QLabel *labelNombre = new QLabel("Nombre:", this);
    layout->addWidget(labelNombre, 1, 0);
    lineEditNombre = new QLineEdit(this);
    layout->addWidget(lineEditNombre, 1, 1);

    QLabel *labelApellido = new QLabel("Apellido:", this);
    layout->addWidget(labelApellido, 2, 0);
    lineEditApellido = new QLineEdit(this);
    layout->addWidget(lineEditApellido, 2, 1);

    QPushButton *button = new QPushButton("Aceptar", this);
    connect(button, &QPushButton::clicked, this, &Formulario::cerrarFormulario);
    layout->addWidget(button, 3, 1);
}

void Formulario::cerrarFormulario() {
    emit cerrar();
}
