#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <QLineEdit>

class Login : public QWidget {
    Q_OBJECT
public:
    Login(QWidget *parent = nullptr);

signals:
    void mostrarFormulario();

private slots:
    void verificarCredenciales();

private:
    QLineEdit *lineEditUsuario;
    QLineEdit *lineEditClave;
};

#endif // LOGIN_H
