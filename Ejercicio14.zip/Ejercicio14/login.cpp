#include "login.h"
#include "formulario.h"
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QDebug>

Login::Login(QWidget *parent) : QWidget(parent) {
    QGridLayout *layout = new QGridLayout(this);

    QLabel *labelUsuario = new QLabel("Usuario:", this);
    layout->addWidget(labelUsuario, 0, 0);
    lineEditUsuario = new QLineEdit(this);
    layout->addWidget(lineEditUsuario, 0, 1);

    QLabel *labelClave = new QLabel("Clave:", this);
    layout->addWidget(labelClave, 1, 0);
    lineEditClave = new QLineEdit(this);
    lineEditClave->setEchoMode(QLineEdit::Password);
    layout->addWidget(lineEditClave, 1, 1);
    connect(lineEditClave, &QLineEdit::returnPressed, this, &Login::verificarCredenciales);

    QPushButton *button = new QPushButton("Ingresar", this);
    connect(button, &QPushButton::clicked, this, &Login::verificarCredenciales);
    layout->addWidget(button, 2, 1);
}

void Login::verificarCredenciales() {
    QString usuario = lineEditUsuario->text();
    QString clave = lineEditClave->text();

    if (usuario == "admin" && clave == "1111") {
        emit mostrarFormulario();
    } else {
        lineEditUsuario->clear();
        lineEditClave->clear();
    }
}
