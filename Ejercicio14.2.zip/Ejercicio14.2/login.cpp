#include "login.h"
#include "mapa.h"
#include<QPainter>
#include<QDebug>
#include<QDesktopWidget>
#include <QApplication>

#include <QJsonDocument>
#include <QJsonObject>

Login::Login(QWidget *parent) : QWidget (parent)
{
    setWindowTitle("Login");

    lUsuario = new QLabel("Usuario");
    lClave = new QLabel ("Clave");
    lClima = new QLabel ("");
    leUsuario = new QLineEdit("admin");
    leClave = new QLineEdit("1234");
    leClave->setEchoMode(QLineEdit::Password);
    pbEntrar = new QPushButton("Entrar");
    layout = new QGridLayout;
    mapa = new Mapa;



    layout -> addWidget (lUsuario, 0, 0, 1, 1);
    layout -> addWidget (lClave, 1, 0, 1, 1);
    layout -> addWidget (lClima, 2, 0, 1, 1);
    layout -> addWidget (leUsuario, 0, 1, 1, 2);
    layout -> addWidget (leClave, 1, 1, 1, 2);
    layout -> addWidget (pbEntrar, 2, 1, 1, 1);

    this -> setLayout (layout);

    connect(pbEntrar, SIGNAL(pressed()), this, SLOT (slot_validarUsuario()));
    connect(leClave, SIGNAL(returnPressed()), this, SLOT (slot_validarUsuario()));

    manager = new QNetworkAccessManager( this );
    managerClima = new QNetworkAccessManager( this );

    connect( manager, SIGNAL(finished(QNetworkReply*)),
             this, SLOT(slot_descargafinalizada(QNetworkReply*)));

    connect( managerClima, SIGNAL(finished(QNetworkReply*)),
             this, SLOT(slot_descargafinalizadaClima(QNetworkReply*)));

//    QNetworkRequest request( QUrl("http://www.jasoft.org/Blog/image.axd?picture=/2019/Win10-1903-01.jpg"));
    QNetworkRequest request( QUrl("https://articles-img.sftcdn.net/t_articles/auto-mapping-folder/sites/2/2023/03/fondo-aesthetic-cielo-noche.jpg"));
    manager->get( request);


    QNetworkRequest requestClima( QUrl("https://api.weatherapi.com/v1/current.json?key=6ebf146961d24c06b6a02801241104&q=Cordoba&aqi=no"));

    managerClima->get( requestClima );



}

void Login::paintEvent(QPaintEvent *) {
    QPainter painter( this);

    if ( ! im.isNull() )
        painter.drawImage(0, 0, im.scaled(this->width(), this->height()));

}


void Login::slot_validarUsuario() {
    if (leUsuario -> text() == "admin" && leClave -> text() == "1234"){
        qDebug() <<"Usuario Valido";

        QDesktopWidget *desktop = QApplication::desktop();
        QRect screenRect = desktop->screenGeometry();

        mapa->resize( screenRect.width() / 2, screenRect.height() / 2 );


        int x = screenRect.width() / 2 - mapa->width() / 2;
        int y = screenRect.height() / 2 - mapa->height() / 2;

        mapa->move(x, y);

        mapa->show();
        this->close();
    }
    else {
        leClave->clear();
    }
}

void Login::slot_descargafinalizada(QNetworkReply *reply)
{
   im  = QImage::fromData( reply->readAll());

   this->repaint();  // invoca a paintEvent
}

void Login::slot_descargafinalizadaClima(QNetworkReply *reply)
{
   QByteArray jsonDevuelto = reply->readAll();
   qDebug() << jsonDevuelto;

   // Parse the JSON string
   QJsonDocument doc = QJsonDocument::fromJson(jsonDevuelto);

   // Check if parsing was successful
   if (doc.isObject()) {
     // Get the "current" object
     QJsonObject currentObject = doc.object()["current"].toObject();

     // Check if the "current" object exists
     if (currentObject.contains("temp_c")) {
       // Extract the temperature in Celsius
       double temperatureC = currentObject["temp_c"].toDouble();
       qDebug() << "Temperature (Celsius):" << temperatureC;

       lClima->setText( QString::number(temperatureC) );


     } else {
       qDebug() << "Error: 'temp_c' key not found in 'current' object";
     }
   } else {
     qDebug() << "Error: Invalid JSON format";
   }


}


