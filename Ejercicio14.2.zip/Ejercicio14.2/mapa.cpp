#include "mapa.h"
#include<QPainter>

Mapa::Mapa()
{

}


void Mapa::paintEvent (QPaintEvent *)  {
    QPainter painter(this);

    painter.drawLine (0, 0, this->width(), this->height());
    QImage im("C:/Users/ignad/Pictures/poo imagenes/descarga.jpeg");
    painter.drawImage(0, 0, im.scaled(this->width(), this->height()));
};
